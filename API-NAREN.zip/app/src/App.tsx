import { useState } from 'react';
import { 
  Bot, Wrench, Download, Search, UserSearch, Shuffle, Server, 
  ArrowLeft, Grid3X3, Terminal, Copy, Check, Play, Gamepad2, Moon, Newspaper
} from 'lucide-react';
import { categories, appInfo, type Category, type Endpoint } from './data/api-data';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';

type View = 'home' | 'category' | 'endpoint';

const iconMap: Record<string, React.ElementType> = {
  Bot,
  Wrench,
  Download,
  Search,
  UserSearch,
  Shuffle,
  Server,
  Gamepad2,
  Moon,
  Newspaper,
};

function App() {
  const [currentView, setCurrentView] = useState<View>('home');
  const [selectedCategory, setSelectedCategory] = useState<Category | null>(null);
  const [selectedEndpoint, setSelectedEndpoint] = useState<Endpoint | null>(null);
  const [paramValues, setParamValues] = useState<Record<string, string>>({});
  const [response, setResponse] = useState<string>('{"status": "waiting..."}');
  const [copied, setCopied] = useState(false);

  const handleCategoryClick = (category: Category) => {
    setSelectedCategory(category);
    setCurrentView('category');
    setParamValues({});
    setResponse('{"status": "waiting..."}');
  };

  const handleEndpointClick = (endpoint: Endpoint) => {
    setSelectedEndpoint(endpoint);
    setCurrentView('endpoint');
    setParamValues({});
    setResponse('{"status": "waiting..."}');
  };

  const handleBack = () => {
    if (currentView === 'endpoint') {
      setCurrentView('category');
      setSelectedEndpoint(null);
    } else if (currentView === 'category') {
      setCurrentView('home');
      setSelectedCategory(null);
    }
    setParamValues({});
    setResponse('{"status": "waiting..."}');
  };

  const handleParamChange = (paramName: string, value: string) => {
    setParamValues(prev => ({ ...prev, [paramName]: value }));
  };

  const generateCurl = () => {
    if (!selectedEndpoint) return '';
    const params = selectedEndpoint.params || [];
    const queryParams = params
      .filter(p => paramValues[p.name])
      .map(p => `${p.name}=${encodeURIComponent(paramValues[p.name])}`)
      .join('&');
    const url = `${appInfo.baseUrl}${selectedEndpoint.path}${queryParams ? '?' + queryParams : ''}`;
    return `curl -X ${selectedEndpoint.method} "${url}"`;
  };

  const handleCopyCurl = () => {
    navigator.clipboard.writeText(generateCurl());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleTest = () => {
    setResponse('{"status": "testing..."}');
    setTimeout(() => {
      setResponse(JSON.stringify({
        status: 200,
        success: true,
        message: 'API endpoint is active',
        timestamp: new Date().toISOString(),
        data: {
          endpoint: selectedEndpoint?.path,
          method: selectedEndpoint?.method,
        }
      }, null, 2));
    }, 1000);
  };

  const renderHome = () => (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex flex-col items-center py-8 px-4">
      {/* Animated Background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-1/2 -left-1/2 w-full h-full bg-purple-500/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute -bottom-1/2 -right-1/2 w-full h-full bg-blue-500/10 rounded-full blur-3xl animate-pulse delay-1000" />
      </div>

      {/* Hero Video */}
      <div className="w-full max-w-[780px] mb-4 relative z-10">
        <video
          src="/video.mp4"
          autoPlay
          loop
          muted
          playsInline
          className="w-full h-auto rounded-xl shadow-2xl shadow-purple-500/20"
        />
      </div>

      {/* Title Card */}
      <Card className="w-full max-w-[780px] mb-4 bg-white/5 backdrop-blur-lg border border-white/10 shadow-xl relative z-10">
        <CardContent className="p-6 text-center">
          <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-400 via-pink-400 to-blue-400 bg-clip-text text-transparent mb-2">
            {appInfo.name}
          </h1>
          <p className="text-sm text-gray-400 font-mono mb-4">
            {appInfo.subtitle}
          </p>
          <Badge 
            variant="secondary" 
            className="bg-gradient-to-r from-purple-600 to-blue-600 text-white hover:from-purple-700 hover:to-blue-700 font-mono text-xs px-4 py-1"
          >
            {appInfo.version}
          </Badge>
        </CardContent>
      </Card>

      {/* Categories Card */}
      <Card className="w-full max-w-[780px] bg-white/5 backdrop-blur-lg border border-white/10 shadow-xl relative z-10">
        <CardContent className="p-6">
          <div className="flex items-center gap-2 mb-6">
            <Grid3X3 className="w-5 h-5 text-purple-400" />
            <h2 className="text-lg font-semibold text-white">
              API Categories
            </h2>
            <span className="ml-auto text-xs text-gray-400 font-mono">
              {categories.reduce((acc, cat) => acc + cat.endpointCount, 0)} endpoints
            </span>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {categories.map((category) => {
              const IconComponent = iconMap[category.icon] || Bot;
              return (
                <div
                  key={category.id}
                  onClick={() => handleCategoryClick(category)}
                  className="p-4 rounded-xl bg-white/5 border border-white/10 hover:border-purple-500/50 hover:bg-white/10 transition-all cursor-pointer group"
                >
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-purple-600 to-blue-600 flex items-center justify-center group-hover:scale-110 transition-transform">
                      <IconComponent className="w-5 h-5 text-white" />
                    </div>
                    <span className="font-semibold text-white group-hover:text-purple-300 transition-colors">
                      {category.name}
                    </span>
                  </div>
                  <p className="text-xs text-gray-400 mb-1">
                    {category.description}
                  </p>
                  <p className="text-xs text-purple-400 font-mono">
                    {category.endpointCount} endpoints
                  </p>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Footer */}
      <div className="mt-8 text-center relative z-10">
        <p className="text-sm text-gray-500">
          Created with by
        </p>
        <p className="text-sm font-semibold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
          {appInfo.author}
        </p>
      </div>
    </div>
  );

  const renderCategory = () => {
    if (!selectedCategory) return null;
    const IconComponent = iconMap[selectedCategory.icon] || Bot;

    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex flex-col items-center py-8 px-4">
        {/* Animated Background */}
        <div className="fixed inset-0 overflow-hidden pointer-events-none">
          <div className="absolute -top-1/2 -left-1/2 w-full h-full bg-purple-500/10 rounded-full blur-3xl animate-pulse" />
          <div className="absolute -bottom-1/2 -right-1/2 w-full h-full bg-blue-500/10 rounded-full blur-3xl animate-pulse delay-1000" />
        </div>

        {/* Header */}
        <Card className="w-full max-w-[780px] mb-4 bg-white/5 backdrop-blur-lg border border-white/10 shadow-xl relative z-10">
          <CardContent className="p-6">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleBack}
              className="mb-4 -ml-2 text-gray-400 hover:text-white hover:bg-white/10"
            >
              <ArrowLeft className="w-4 h-4 mr-1" />
              Back
            </Button>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-purple-600 to-blue-600 flex items-center justify-center">
                <IconComponent className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-white">
                  {selectedCategory.name}
                </h1>
                <p className="text-sm text-gray-400">
                  {selectedCategory.description}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Endpoints List */}
        <Card className="w-full max-w-[780px] bg-white/5 backdrop-blur-lg border border-white/10 shadow-xl relative z-10">
          <CardContent className="p-6">
            <div className="space-y-3">
              {selectedCategory.endpoints.map((endpoint) => (
                <div
                  key={endpoint.id}
                  onClick={() => handleEndpointClick(endpoint)}
                  className="p-4 rounded-xl bg-white/5 border border-white/10 hover:border-purple-500/50 hover:bg-white/10 transition-all cursor-pointer group"
                >
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="font-semibold text-white group-hover:text-purple-300 transition-colors">
                      {endpoint.name}
                    </h3>
                    <Badge 
                      variant={endpoint.method === 'GET' ? 'default' : 'secondary'}
                      className={`font-mono text-xs ${
                        endpoint.method === 'GET' 
                          ? 'bg-green-500/20 text-green-400 border border-green-500/30' 
                          : 'bg-orange-500/20 text-orange-400 border border-orange-500/30'
                      }`}
                    >
                      {endpoint.method}
                    </Badge>
                  </div>
                  <code className="text-xs text-purple-400 font-mono block mb-1">
                    {endpoint.path}
                  </code>
                  <p className="text-xs text-gray-400">
                    {endpoint.description}
                  </p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="mt-8 text-center relative z-10">
          <p className="text-sm text-gray-500">
            Created with ❤️ by
          </p>
          <p className="text-sm font-semibold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
            {appInfo.author}
          </p>
        </div>
      </div>
    );
  };

  const renderEndpoint = () => {
    if (!selectedEndpoint || !selectedCategory) return null;

    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex flex-col items-center py-8 px-4">
        {/* Animated Background */}
        <div className="fixed inset-0 overflow-hidden pointer-events-none">
          <div className="absolute -top-1/2 -left-1/2 w-full h-full bg-purple-500/10 rounded-full blur-3xl animate-pulse" />
          <div className="absolute -bottom-1/2 -right-1/2 w-full h-full bg-blue-500/10 rounded-full blur-3xl animate-pulse delay-1000" />
        </div>

        {/* Header */}
        <Card className="w-full max-w-[780px] mb-4 bg-white/5 backdrop-blur-lg border border-white/10 shadow-xl relative z-10">
          <CardContent className="p-6">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleBack}
              className="mb-4 -ml-2 text-gray-400 hover:text-white hover:bg-white/10"
            >
              <ArrowLeft className="w-4 h-4 mr-1" />
              Back
            </Button>
            <div className="flex items-start justify-between">
              <div>
                <h1 className="text-xl font-bold text-white mb-2">
                  {selectedEndpoint.name}
                </h1>
                <div className="flex items-center gap-3">
                  <Badge 
                    variant={selectedEndpoint.method === 'GET' ? 'default' : 'secondary'}
                    className={`font-mono text-xs ${
                      selectedEndpoint.method === 'GET' 
                        ? 'bg-green-500/20 text-green-400 border border-green-500/30' 
                        : 'bg-orange-500/20 text-orange-400 border border-orange-500/30'
                    }`}
                  >
                    {selectedEndpoint.method}
                  </Badge>
                  <code className="text-sm text-purple-400 font-mono">
                    {selectedEndpoint.path}
                  </code>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Parameters & Test */}
        <Card className="w-full max-w-[780px] mb-4 bg-white/5 backdrop-blur-lg border border-white/10 shadow-xl relative z-10">
          <CardContent className="p-6">
            {selectedEndpoint.params && selectedEndpoint.params.length > 0 ? (
              <div className="space-y-4 mb-6">
                {selectedEndpoint.params.map((param) => (
                  <div key={param.name}>
                    <label className="text-sm text-gray-300 block mb-2">
                      {param.name}:
                      {!param.required && (
                        <span className="text-gray-500 text-xs ml-1">(optional)</span>
                      )}
                    </label>
                    <Input
                      type={param.type === 'file' ? 'file' : 'text'}
                      placeholder={`Enter ${param.name}...`}
                      value={paramValues[param.name] || ''}
                      onChange={(e) => handleParamChange(param.name, e.target.value)}
                      className="bg-white/5 border-white/10 text-white placeholder:text-gray-500 focus:border-purple-500 focus:ring-purple-500/20"
                    />
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-gray-400 mb-6">
                No parameters required for this endpoint.
              </p>
            )}
            
            <Button
              onClick={handleTest}
              className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-semibold"
            >
              <Play className="w-4 h-4 mr-2" />
              Test Now
            </Button>
          </CardContent>
        </Card>

        {/* Response */}
        <Card className="w-full max-w-[780px] mb-4 bg-white/5 backdrop-blur-lg border border-white/10 shadow-xl relative z-10">
          <CardContent className="p-6">
            <h3 className="text-sm font-semibold text-white mb-4">
              Response
            </h3>
            <div className="flex items-center gap-4 mb-4">
              <div className="flex items-center gap-2">
                <span className="text-xs text-gray-500 font-mono">-</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-gray-500 font-mono">-</span>
              </div>
            </div>
            <div className="bg-black/30 rounded-lg p-4 border border-white/10">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-gray-500 font-mono">response.json</span>
              </div>
              <pre className="text-xs font-mono text-green-400 overflow-x-auto">
                {response}
              </pre>
            </div>
          </CardContent>
        </Card>

        {/* cURL */}
        <Card className="w-full max-w-[780px] mb-4 bg-white/5 backdrop-blur-lg border border-white/10 shadow-xl relative z-10">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Terminal className="w-4 h-4 text-purple-400" />
                <span className="text-sm font-semibold text-white">cURL</span>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleCopyCurl}
                className="text-gray-400 hover:text-white hover:bg-white/10"
              >
                {copied ? (
                  <Check className="w-4 h-4 text-green-400" />
                ) : (
                  <Copy className="w-4 h-4" />
                )}
              </Button>
            </div>
            <div className="bg-black/50 rounded-lg p-4 border border-white/10">
              <code className="text-xs font-mono text-green-400 block">
                {generateCurl()}
              </code>
            </div>
          </CardContent>
        </Card>

        {/* Status Codes */}
        <Card className="w-full max-w-[780px] bg-white/5 backdrop-blur-lg border border-white/10 shadow-xl relative z-10">
          <CardContent className="p-6">
            <h3 className="text-sm font-semibold text-white mb-4">
              Status Codes
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center p-3 rounded-lg bg-green-500/10 border border-green-500/20">
                <Badge className="bg-green-500/20 text-green-400 mb-2">200</Badge>
                <p className="text-xs text-gray-400">Success</p>
              </div>
              <div className="text-center p-3 rounded-lg bg-yellow-500/10 border border-yellow-500/20">
                <Badge className="bg-yellow-500/20 text-yellow-400 mb-2">400</Badge>
                <p className="text-xs text-gray-400">Bad Request</p>
              </div>
              <div className="text-center p-3 rounded-lg bg-orange-500/10 border border-orange-500/20">
                <Badge className="bg-orange-500/20 text-orange-400 mb-2">404</Badge>
                <p className="text-xs text-gray-400">Not Found</p>
              </div>
              <div className="text-center p-3 rounded-lg bg-red-500/10 border border-red-500/20">
                <Badge className="bg-red-500/20 text-red-400 mb-2">500</Badge>
                <p className="text-xs text-gray-400">Server Error</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="mt-8 text-center relative z-10">
          <p className="text-sm text-gray-500">
            Created with ❤️ by
          </p>
          <p className="text-sm font-semibold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
            {appInfo.author}
          </p>
        </div>
      </div>
    );
  };

  return (
    <div className="font-sans">
      {currentView === 'home' && renderHome()}
      {currentView === 'category' && renderCategory()}
      {currentView === 'endpoint' && renderEndpoint()}
    </div>
  );
}

export default App;
